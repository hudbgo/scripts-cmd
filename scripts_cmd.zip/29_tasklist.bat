@echo off
tasklist
pause