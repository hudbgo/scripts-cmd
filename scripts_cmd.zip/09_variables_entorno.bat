@echo off
set
pause